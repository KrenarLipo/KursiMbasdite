<?php
$login_error_message = '';
  $register_error_messagge ='';
  if(isset($_POST['login-user'])){
    if(empty($_POST["user-email"])||empty($_POST['user-password'])){
      $login_error_message = '<label>Te gjitha fushat jane te detyrueshme</label>';
    }else{
      $databaselogin = new Connection();
      $db = $databaselogin->open();
      try {
        $query = "SELECT * FROM users WHERE name = :username AND passwordi = :password";
        $stmt = $db->prepare($query);
        $stmt->execute(
              array(
                'username'=>$_POST['login-user'],
                'password'=>password_hash($_POST['user-password'],PASSWORD_DEFAULT);
              )
        );
        $count = $stmt->rowCount();
        if($count>0){
          $_SESSION["username"] = $_POST["login-user"];
          header('location:listoMakinat.php');
        }else{
          header('location: login.php');
        }
      }catch(PDOException $e) {
        $_SESSION['message'] = "Ka nje problem me userin: " . $e->getMessage();
      }
    }
  }else{
    $login_error_message = "Mungojne te dhenat ne login!";
  }

  ?>