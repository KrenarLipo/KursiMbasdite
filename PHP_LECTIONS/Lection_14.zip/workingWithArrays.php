<?php

$frutat = ["Molle", "Portokall", "Luleshtrydhe", "Banane", "Kivi"];
$cmimet = [120, 140, 200, 170, 80];

echo"<center>";
echo"<pre>";
print_r($frutat);
echo"</pre><hr>";

foreach($frutat as $f){
    echo $f."<br>";
}
echo"<hr>";
var_dump($frutat);
echo"<hr>";
$newArray = array_combine($frutat, $cmimet);

echo"<pre>";
print_r($newArray);
echo"</pre><hr>";
//Kontrollojme nese ndodhet ne array
if(in_array('Mandarina',$frutat)){
    echo "Bananja ndodhet ne tabele";
}else{
    echo "Elementi nuk ndodhet ne tabele";
}

//Numeron sa here ndodhet fjala kiv ne array
$sasia = array_search('Kivi', $frutat);
echo "<hr><br>".$frutat[$sasia];
echo "</center>";



