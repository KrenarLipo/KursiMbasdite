<?php
session_start();
include "header.php";
?>
<div class="container-fluid imazhaboutus">
    <h2><a href="ForgotPassword.php">Harrova Passwordin</a></h2>
</div>
<div class="container">
    <div class="col-md-3">
    </div>
    <div class="col-md-6">
        <form action="loginpage.php" method ="get">
        <div class="form-group">
            <label for="useremail">User email:</label> 
            <input id="useremail" class="form-control" name="user-email" type="email" value="Jep email">
        </div>
        <div class="form-group">
            <label for="userpassword">User password:</label> 
            <input id="userpassword" class="form-control" name="user-password" type="password" value="Jepi password">
        </div>      
            <input class="btn btn-primary" name="login-user" type="submit" value="Logohuni">
        </form>
    </div>
    <div class="col-md-3">
    </div>
</div>


