<?php
session_start();
include "header.php";
?>
<div class="col-md-3">
</div>
<div class="col-md-6">
        <form action="updatePassword.php" method ="post">
        <div class="form-group">
            <label for="usernewpassword">New Password:</label> 
            <input id="usernewpassword" class="form-control" name="user-new-password" type="password" value="">
        </div>
        <div class="form-group">
            <label for="userconfirmpassword">Confirm password:</label> 
            <input id="userconfirmpassword" class="form-control" name="user-confirm-password" type="password" value="">
        </div>      
            <input class="btn btn-primary" name="add-user" type="submit" value="Rinovo password">
        </form>
    </div>
    <div class="col-md-3">
    </div>