<?php 

//footer element

?>

</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript">
    $(document).ready(function(){
         var dataTable = $("#user_data").DataTable({
                "processing":true,
                "serverSide":true,
                "order": [],
                "ajax": {
                    url:"fetchUsers.php",
                    type: "POST",
                },
                columns: [
                    {
                        "name": "id",
                        "searchable":false,
                        "orderable":true
                    },
                    {
                        "name": "username",
                        "searchable":true,
                        "orderable":true
                    },
                    {
                        "name": "surname",
                        "searchable":false,
                        "orderable":true
                    },
                    {
                        "name": "email",
                        "searchable":false,
                        "orderable":false
                    },
                    {
                        "name": "phone",
                        "searchable":false,
                        "orderable":false
                    }
                ],
         });       
    });
</script>

</html>