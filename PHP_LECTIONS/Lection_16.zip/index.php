<?php 
include "header.php";
  session_start();
  if(isset($_SESSION['message'])){
      ?>
      <div class="alert alert-info text-center" style="margin-top:20px;">
          <?php echo $_SESSION['message']; ?>
      </div>
      <?php

      unset($_SESSION['message']);
  }
?>
<style>
.text-left {
  float:left;
  margin-bottom:20px;
}
</style>

<?php
  $database = new Connection();
  $db = $database->open();
?>
<div class="container">

   <?php 
     $pasword_uncripted = "1234";
     echo $pasword_uncripted.'<br/>';
     echo password_hash($pasword_uncripted, PASSWORD_DEFAULT);          
?>

</div>

<div class="container">
    
</div>

<?php
  include "footer.php";
?>