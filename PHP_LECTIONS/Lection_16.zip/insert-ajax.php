<?php
session_start();
include "header.php";

?>
<div class="container">
<div class="row">
    <h3>Userat tane</h3>
    <div class="table-responsive">
        <table id="user_data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Surname</th>
                    <th>Email</th>
                    <th>Phone</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
</div>

<?php
include "footer.php";
?>

