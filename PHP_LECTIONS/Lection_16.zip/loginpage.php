<?php
session_start();
include "header.php"; 
  $login_error_message = '';
  $register_error_messagge ='';
  if(isset($_POST['login-user'])){
    if(empty($_POST["user-email"])||empty($_POST['user-password'])){
      $login_error_message = '<label>Te gjitha fushat jane te detyrueshme</label>';
    }else{
      $databaselogin = new Connection();
      $db = $databaselogin->open();
      try {
        $stmt = $db->prepare("SELECT * FROM users WHERE name = :username AND passwordi = :password");
        $stmt->execute(
              array(
                ':username'=>$_POST['login-username'],
                ':password'=>password_hash($_POST['user-password'],PASSWORD_DEFAULT)
              )
        );
        $count = $stmt->rowCount();
        if($count>0){
          $_SESSION["username"] = $_POST["login-username"];
          header('location: http://localhost/KursiMbasdite/PHPLections/listoMakinat.php');
        }else{
          header('location: http://localhost/KursiMbasdite/PHPLections/login.php');
        }
      }catch(PDOException $e) {
        $_SESSION['message'] = "Ka nje problem me userin: " . $e->getMessage();
      }
      //close connection
		  $db = $databaselogin->close();
    }
  }else{
    $login_error_message = "Mungojne te dhenat ne login!";
  }

  ?>