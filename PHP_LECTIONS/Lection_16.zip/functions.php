<?php

function get_total_all_records(){
    
    $username = 'root';
    $password = '';
    $dbc = new PDO('mysql:host=localhost; dbname = php_connection', $username, $password);

    $statement = $dbc->prepare("SELECT * FROM users");
    $statement->execute();
    
    return $statement->rowCount();
}