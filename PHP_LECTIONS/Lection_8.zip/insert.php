<?php
include "header.php";
?>
<style>
    .wrapper {
      margin:10px auto;
      text-align: center;
      width:960px;
      padding:10px;
      border:1px solid #000;
  }
</style>
<?php 
    
    if(!empty($_POST["add_record"])){

        $sql = "INSERT INTO cars (car_name, year_production, price, currency, transmission, fuel) VALUES(:car_name,:car_year,:car_price,:car_currency,:car_transmission,:car_fuel)";
        $pdo_statement = $dbh->prepare($sql);

        $result = $pdo_statement->execute(array(':car_name'=>$_POST['car_name'], ':car_year'=>$_POST['number'], ':car_price'=>$_POST['price'],
                                                ':car_currency'=>$_POST['currency'], ':car_transmission'=>$_POST['transmission'], ':car_fuel'=>$_POST['fuel']));
        if(!empty($result)){
            echo "Makina u shtua me sukses!";
            header('Refresh: 3; url = http://localhost/KursiMbasdite/PHPLections/index.php');
        }
    }
?>
<div class="wrapper">
    <form action="" method="post">
        Car Name: <input type = "text" name="car_name" />
        Currency: <input type = "text" name="currency" />
        Transmission: <input type = "text" name="transmission" />
        Fuel: <input type = "text" name="fuel" />
        Price: <input type="number" name="price" />
        Year of Production: <input type="number" name="number" />
        <input name="add_record" type="submit" value="Shto Makine" class="form-submit">
    </form>
</div>
