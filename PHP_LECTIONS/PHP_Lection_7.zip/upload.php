<?php

$target_dir = "uploads/";

$target_file = $target_dir . basename($_FILES['fileToUpload']['name']);

$uploadOK = 1;

$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

//Kontrollojme nese file-i eshte i sakte
if(isset($_POST["submit"])){
    $check = getimagesize($_FILES['fileToUpload']['tmp_name']);
    if($check !==false){
        echo "File is an image - " . $check["mime"].".";
        $uploadOK = 1;
    }else{
        echo "File is not an image";
        $uploadOK = 0;
    }
}
//Kontrollojme nese file-i egziston
if(file_exists($target_file)){
    echo "File-i egsiton";
    $uploadOK = 0;
}
//Kontrollojme size-in e lejuar te file-it tone
if($_FILES["fileToUpload"]["size"] > 40000000){
    echo "Na vjen keq, por file-i eshte shume i madh";
}
//kontroll final
if($uploadOK == 0) {
    echo "Gabim";
}else{
    if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_file)){
        echo "<br>File-i". htmlspecialchars(basename($_FILES['fileToUpload']['name']))."u uplodua";
        header("Location: http://localhost/KursiMbasdite/PHPLections/workingWithFiles.php");
    }else{
        echo "Ka nje gabim";
    }
}