<?php
session_start();
include "header.php";

if(isset($_POST['log_on'])){

      $username = $_POST['user-name'];
      $password = password_hash($_POST['user-password'], PASSWORD_DEFAULT);
     
      $database = new Connection();
      $db = $database->open();
      try {
        $stmt = $db->prepare("SELECT id FROM users WHERE name = :username AND password = :userpassword ");
        $stmt->bindParam('username', $username, PDO::PARAM_STR);
        $stmt->bindParam('userpassword', $password, PDO::PARAM_STR);
        $stmt->execute();
        
        $count = $stmt->rowCount();
        ?>
        <h4><?php echo "kotifare " .$count; ?></h4>
        <?php         
        if($count > 0){
          $_SESSION["username"] = $username;
          header('location: listoMakinat.php');
        }else{
          header('location: login.php');
        }
      }catch(PDOException $e) {
        $_SESSION['message'] = "Ka nje problem me userin: " . $e->getMessage();
      }
       //close connection
		   $database->close();
  }else{
    $login_error_message = "Mungojne te dhenat ne login!";
  }


?>
<div class="container-fluid imazhaboutus">
    <h2><a href="ForgotPassword.php">Harrova Passwordin</a></h2>
</div>
<div class="container">
    <div class="col-md-3">
    </div>
    <div class="col-md-6">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method ="post">
        <div class="form-group">
            <label for="user-name">User name:</label> 
            <input id="user-name" class="form-control" name="user-name" type="text" value="">
        </div>
        <div class="form-group">
            <label for="userpassword">User password:</label> 
            <input id="userpassword" class="form-control" name="user-password" type="password" value="">
        </div>      
            <input class="btn btn-primary" name="log_on" type="submit" value="Logohuni">
        </form>
    </div>
    <div class="col-md-3">
    </div>
</div>


