<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link type="text/css" rel="stylesheet" href="css/app.css">

    <style>
        @page { 
            margin: 0px;
            height: 100vh;
        }

        @font-face {
            font-family: 'Montserrat';
            font-style: normal;
            font-weight: 400;
            src: url({{storage_path('/fonts/Montserrat-Regular.ttf')}});
            font-display: swap;
        }

        body {
            margin: 0px;
            /* font-family: 'Montserrat', sans-serif; */
        }

        header {
            border-top: 40px solid #3989c6;
        }

        footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            border-bottom: 40px solid #3989c6;
        }

        .bg-blue { 
            background-color: #3989c6 !important;
        }

        .bg-grey {
            background-color: #eeeeee;
        }

        .text-blue {
            color: #3989c6;
        }

        .text-grey {
            color: #aaa;
        }

        .text-white {
            color: white;
        }

        .w-100 {
            width: 100%;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-35 {
            width: 35% !important;
        }

        .w-25 {
            width: 25% !important;
        }

        .w-15 {
            widht: 15% !important;
        }

        .no-border {
            border: none !important;
        }

        .border-bottom-blue {
            border-bottom: 5px #3989c6 solid !important;
        }

        .border-bottom-thin {
            border-bottom: 1px #ddd solid !important;
        }

        .text-08 {
            font-size: 0.8rem !important;
        }

        .text-07 {
            font-size: 0.7rem !important;
        }

    </style>
</head>

<body>
    <div class="fakeNav bg-blue text-blue">Sabicom Srl</div>

    <!--to be left as a memory of a time past-->
    <!--Author: @xhevo-->

    <div class="p-3">
        <div class="invoice overflow-auto">
            
            <table class="w-100">
                <tr>
                    <td class="pl-5 no-border">
                        <h3 class="text-blue">Trentin Oil di Trentin Giuseppe & C. SNC</h3>
                        <div>Via Statue 92 </div>
                        <div> 35015 GALLIERA VENETA (PD)</div>
                        <br>
                        <div>P.IVA: <strong>00154020283</strong></div>
                        <div>C.F.: <strong>00154020283</strong></div>
                        <div>Email: trentinoil@alice.it </div>
                        <div>Telefono: 3474103617 </div>
                    </td>
                    <td class="no-border">
                        <!-- {{-- LOGO --}} -->
                    </td>
                </tr>

                <tr>
                    <td class="bg-blue text-white mt-4 pl-3">
                        Fattura N.: 188
                    </td>
                    <td class="bg-blue text-white text-right mt-4 pr-3">
                        Data: 02/03/2021
                    </td>
                </tr>

                <tr>
                    <td class="w-50 pl-5 no-border">
                        <div class="bg-grey px-2 py-2">
                            MODALITÀ DI PAGAMENTO:
                            <div>
                            Carta credito
                            </div>
                        </div>
                    </td>
                    <td class="w-50 text-right pr-5 no-border">
                        <small>INTESTATA A:</small>
                        <br>
                        <h4 class="text-blue">FINESTRE & DESIGN S.R.L.</h4>
                        <div>VIA G VERDI 4/5</div>
                        <div>35013
                            CITTADELLA (PD)
                        </div>

                        <div>
                            P.IVA: <strong>04953550284</strong>
                        </div>
                        <div>Codice Destinatario: M5UXCR1 </div>
                    </td>
                </tr>
            </table>

            <div class="table-responsive px-5 w-100 mt-2">
                <table class="table">
                    <thead>
                        <tr>
                            <th colspan="2" class="text-center text-white bg-blue"><small>ARTICOLO</small></th>
                            <th class="text-center text-white bg-blue"><small>TARGA</small></th>
                            <th class="text-center text-white bg-blue"><small>PREZZO UNITARIO</small></th>
                            <th class="text-center text-white bg-blue"><small>QUANTITÀ</small></th>
                            <th class="text-center text-white bg-blue"><small>% IVA</small></th>
                            <th class="text-center text-white bg-blue"><small>IMPONIBILE</small></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="2" class="pl-4 py-2">
                                <div class="text-08">
                                    Gasolio Q8
                                <div>
                            </td>
                            <td class="p-2 text-center text-08">
                                GE345KC
                            </td>    
                            <td class="p-2 text-center text-08">
                                 &euro; 1.150
                            </td>
                            <td class="p-2 text-center text-08"> 
                                60.592 
                            </td>
                            <td class="p-2 text-center text-08">
                                22.00%  
                            </td>
                            <td class="pr-4 py-2 text-right text-08"> 
                                &euro; 69.68 
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="px-5 w-100 text-08">
                <table class="w-100">
                    <tr>
                        <td class="w-50 border-bottom-blue text-right py-1">
                            TOTALE IMPONIBILE
                        </td>
                                    
                        <td class="w-15 border-bottom-blue text-right py-1 pr-4">
                            &euro; 69.68
                        </td>
                    </tr>
                    <tr>
                        <td class="w-50"></td>

                        <td class="w-25 text-right py-1">
                            <strong>IVA </strong>
                        </td>

                        <td class="w-25 text-right py-1 pr-4">
                            &euro; 15.33
                        </td>
                    </tr>

                    <tr>
                        <td class="w-50 bg-blue"></td>

                        <td class="w-25 bg-blue text-white text-right">
                            TOTALE FATTURA
                        </td>

                        <td class="w-25 bg-blue text-white text-right pr-4">
                            &euro; 85.01
                        </td>
                    </tr>
                </table>
            </div>

        </div>
    </div>
    
    <footer id="footer" class="m-0 text-center">
        <div class="text-center text-grey pb-2">
            <small class="text-08 align-middle">CREATO CON</small>
        </div>
        <div>
            <img src="img/Logo_FatturareOnline.png" height="30px">
        </div>
    </footer>
    
</body>

</html>