<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link type="text/css" rel="stylesheet" href="css/app.css">

    <style>
        @page { 
            margin: 0px;
            height: 100vh;
        }

        @font-face {
            font-family: 'Montserrat';
            font-style: normal;
            font-weight: 400;
            src: url({{storage_path('/fonts/Montserrat-Regular.ttf')}});
            font-display: swap;
        }

        body {
            margin: 0px;
            /* font-family: 'Montserrat', sans-serif; */
        }

        header {
            border-top: 40px solid #3989c6;
        }

        footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            /* border-bottom: 40px solid #3989c6; */
        }

        .bg-blue { 
            background-color: #3989c6 !important;
        }

        .bg-grey {
            background-color: #eeeeee;
        }

        .text-blue {
            color: #3989c6;
        }

        .text-grey {
            color: #aaa;
        }

        .text-white {
            color: white;
        }

        .w-100 {
            width: 100% !important;
        }

        .no-border {
            border: none !important;
        }

        .border-bottom-blue {
            border-bottom: 5px #3989c6 solid !important;
        }

        .border-bottom-thin {
            border-bottom: 1px #ddd solid !important;
        }

        .text-08 {
            font-size: 0.8rem !important;
            text-align:center;
        }

        .text-07 {
            font-size: 0.7rem !important;
        }

        .bolded-text {
            font-size:1.75rem;
            font-weight:600;
            color:#000;
        }
        .border-bottom-grey {
            border-bottom: 5px #eeeeee solid !important;
        }

        .border-bottom-light-grey {
            border-bottom: 2px #eeeeee solid !important;
        }
        .grey-border {
            border:2px solid #eeeeee;
        }
        .text-13 {
            font-size: 1.3rem !important;
        }

        .align-left {
            float:left;
            text-align:left;
            padding:10px 30px;
        }

        .size-10 {
            width:10%;
            float:left;
        }

        .size-20 {
            width:20%;
            float:left;
        }

        .size-30 {
            width:30%;
            float:left;
        }

        .size-40 {
            width:40%;
            float:left;
        }

        .size-50 {
            width:50%;
            float:left;
        }

        .size-100 {
            width:100%;
        }

        .p-left {
            padding:10px 30px;
        }

    </style>
</head>

<body>
    <!-- <div class="fakeNav bg-blue text-blue">Sabicom Srl</div> -->

    <!--to be left as a memory of a time past-->
    <!--Author: @xhevo-->

    <div class="container-fluid">
        <div class="invoice overflow-auto">
             <h3 class="text-blue align-left">Trentin Oil di Trentin Giuseppe & C. SNC</h3>
            <table class="table-responsive">
                <tr class="align-left size-100">
                    <td class="no-border size-30">
                        <div>Via Statue 92 </div>
                        <div> 35015 GALLIERA VENETA (PD)</div>
                    </td>
                    <td class="no-border size-30">
                        <div>P.IVA: <strong>00154020283</strong></div>
                        <div>C.F.: <strong>00154020283</strong></div>
                    </td>
                    <td class="no-border size-40">
                        <div>Email: trentinoil@alice.it </div>
                        <div>Telefono: 3474103617 </div>
                    </td>
                    
                </tr>
                <tr class="align-left size-100">
                    <td class="bolded-text size-30">
                        Fattura N.: 188
                    </td>
                    <td class="size-30"></td>
                    <td class="bolded-text size-40">
                        Data: 02/03/2021
                    </td>
                </tr>

                <tr class="align-left size-100">
                    <td class="size-30 no-border">
                        <div class="px-2 py-2 grey-border">
                            MODALITÀ DI PAGAMENTO:
                            <div>
                            Carta credito
                            </div>
                        </div>
                    </td>
                    <td class="size-30"></td>
                    <td class="size-40 no-border">
                        <small>INTESTATA A:</small>
                        <br>
                        <h4 class="text-blue text-13">FINESTRE & DESIGN S.R.L.</h4>
                        <div>VIA G VERDI 4/5</div>
                        <div>35013
                            CITTADELLA (PD)
                        </div>

                        <div>
                            P.IVA: <strong>04953550284</strong>
                        </div>
                        <div>Codice Destinatario: M5UXCR1 </div>
                    </td>
                </tr>
            </table>

            </div>
            <div class="container-fluid">

            <div class="table-responsive p-left w-100 mt-2">
                <table class="table">
                    <thead>
                        <tr>
                            <th colspan="2" class="text-center"><small>ARTICOLO</small></th>
                            <th class="text-center"><small>TARGA</small></th>
                            <th class="text-center"><small>PREZZO UNITARIO</small></th>
                            <th class="text-center"><small>QUANTITÀ</small></th>
                            <th class="text-center"><small>% IVA</small></th>
                            <th class="text-center"><small>IMPONIBILE</small></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="2" class="pl-4 py-2">
                                <div class="text-08">
                                    Gasolio Q8
                                <div>
                            </td>
                            <td class="p-2 text-08">
                                GE345KC
                            </td>    
                            <td class="p-2 text-08">
                                 &euro; 1.150
                            </td>
                            <td class="p-2 text-08"> 
                                60.592 
                            </td>
                            <td class="p-2 text-08">
                                22.00%  
                            </td>
                            <td class="pr-4 py-2 text-08"> 
                                &euro; 69.68 
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="p-left w-100 text-08">
                <table class="w-100">
                    <tr>
                        <td class="w-50"></td>

                        <td class="w-25 text-right">
                            <strong>TOTALE FATTURA</strong>
                        </td>

                        <td class="w-25 text-right pr-4">
                            &euro; 85.01
                        </td>
                    </tr>

                    <tr class="border-bottom-light-grey">
                        <td class="w-50"></td>
                        
                        <td class="w-25 text-right py-1">
                            TOTALE IMPONIBILE
                        </td>
                                    
                        <td class="w-25 text-right py-1 pr-4">
                            &euro; 69.68
                        </td>
                    </tr>

                    <tr>
                        <td class="w-50"></td>

                        <td class="w-25 text-right py-1">
                            <strong>IVA </strong>
                        </td>

                        <td class="w-25 text-right py-1 pr-4">
                            &euro; 15.33
                        </td>
                    </tr>

                </table>
            </div>

        </div>
    </div>
    
    <footer id="footer" class="m-0 text-center">
        <div class="text-center text-grey pb-2">
            <small class="text-08 align-middle">CREATO CON</small>
        </div>
        <div>
            <img src="img/Logo_FatturareOnline.png" height="30px">
        </div>
    </footer>
    
</body>

</html>