<?php 
include "header.php";
?>

<style>
  .wrapper {
      margin:0 auto;
      text-align: center;
      width:960px;
      padding:10px;
  }
</style>
<?php

$emer_variabli = "Hello World!";

$emer_variabli = "Hello Grupi!";

$numri_fillestar = 3;

/* Afishimi i variablit */

echo '<div class="wrapper">';
echo $emer_variabli." Teksti i ri."." ".($numri_fillestar+1); // emer_variabli + "Teksti i ri" per JS
echo '</div>';

$stmt = $dbh->query("SELECT * FROM `users`");
$users = $stmt->fetchAll();
echo "<pre>";
print_r($users);
echo"</pre>";

?>