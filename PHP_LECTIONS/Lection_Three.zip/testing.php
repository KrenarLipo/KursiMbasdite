<?php

include "header.php";

//Leksioni per ciklin For 
$arr1 = [2,6,8,10,12];  // var arr1 = [2,6,8,10,12];
$arr2 = [3,5,7,13,17];  // var arr2 = [3,5,7,13,17];

//cikli i pare for
echo "<p><center>";
foreach($arr1 as $t => $a){
    echo $t."=>".$a."</br>";
}
echo "<br>";
//cikli i dyte for
for($i=0; $i<sizeof($arr2); $i++){
    echo $arr2[$i]."<br>";
}
echo"</br>";
echo $arr2[3];  //console.log(arr2[3]);
$arr2[3] = 15;

/*
in javascript

if(ffff){

}else if(dicka tjeter){

}else{
    ffff
}
*/

if($arr2[3] < 15){
    echo "<br>Numri ".$arr2[3]." eshte me i vogel se 15";
}elseif($arr2[3] > 15){
    echo "<br>Numri ".$arr2[3]." nuk eshte me i vogel se 15";
}else{
    echo "<br>Numri ".$arr2[3]." eshte i barabarte me 15";
}
echo"</center></p>";

function getSum($t){
    
    $sum = $t + 1;
    return $sum;
}

$result = getSum(5);
echo $result;

// class Animals {
    
//     function getNumberOf_Foots(){
//         echo "<br>4";
//     }

// }

// $res = new Animals;
// $res->getNumberOf_Foots();
