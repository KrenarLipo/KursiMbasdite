<?php
session_start();
include "header.php";
include "functions.php";

$database = new Connection();
$db = $database->open();

$query = '';
$output = array();

$query .= "SELECT id,username,surname,email,phone FROM users";

/* ==== Searchi i Datatables ==== */
if(isset($_POST["search"]["value"])){
    $query .= 'WHERE username LIKE "%'.$_POST["search"]["value"].'%"';
    $query .= 'OR surname LIKE "%'.$_POST["search"]["value"].'%"';
    $query .= 'OR phone LIKE "%'.$_POST["search"]["value"].'%"';
}
/* ==== Aktivizimi i shigjetave per fitrim ==== */ 
if(isset($_POST["order"])){
    $query .= 'ORDER BY'.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].'';
}else{
    $query .= 'ORDER BY id DESC';
}
/* ==== Afishimi nepermjet numrit te elementeve per faqe (Pagination) ==== */
if($_POST["length"]!= -1) {
    $query .= 'LIMIT '.$_POST['start'] . ', ' .$_POST['length']; // LIMIT(1,5)
}

$stmt = $db->prepare($query);
$stmt->execute();

$result = $stmt->fetchAll(); //Marre gjithe te dhenat nga databasa

$data = array();

$filtered_rows = $stmt->rowCount(); //Gjen gjithe rreshtat qe kemi, totalin

/* ==== Mbushja e array-t data ==== */
foreach($result as $row) {
    $sub_array = array();

    /* ==== mbushja e sub-arrayt per secilin element nga databasa ==== */
    $sub_array = $row["id"];
    $sub_array = $row["username"];
    $sub_array = $row["surname"];
    $sub_array = $row["email"];
    $sub_array = $row["phone"];

    /* ==== kalimi ite dhenave nga sub_array tek data ==== */
    $data[] = $sub_array;
}

/* ==== Mbushja e outputit ==== */
$output = array (
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => $filtered_rows,
    "recordsFiltered" => get_total_all_records(),
    "data" => $data
);

echo json_encode($output);

include "footer.php";
?>