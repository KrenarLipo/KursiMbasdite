<?php 
    session_start();
    include_once('header.php');

    if(isset($_GET['id'])){
        $database = new Connection();
        $dbh = $database->open();
        try {
            $sql = "DELETE FROM cars WHERE id = '".$_GET['id']."'";
            /*
               if($dbh->exec($sql)){
                   echo "Makina u fshi me sukses";
               }else{
                   echo "Makina nuk mund te fshihet";
               }
            */
            $_SESSION['message'] = ($dbh->exec($sql)) ? 'Makina u fshi me sukses':"Makina nuk mund te fshihet";
        
        }catch(PDOException $e){
            $_SESSION['message'] = $e->getMessage();
        }

        //mbyllim lidhjen me databazen
        $database->close();

    }else{
        $_SESSION['message'] = 'Zgjidhni nje makine';
    }

    header('location: index.php');