<?php 
session_start();
include "header.php";

  if(!isset($_SESSION["username"])){
      header("location: http://localhost/KursiMbasdite/PHPLections/login.php");
  }else{
      echo "Mirese ardhet: ".$_SESSION["username"];?>
      <a href="http://localhost/KursiMbasdite/PHPLections/logout.php">Dil</a>
    <?php
  }
  $login_error_message = '';
  $register_error_messagge ='';

?>

<style>
.text-left {
  float:left;
  margin-bottom:20px;
}
</style>

<?php
  $database = new Connection();
  $db = $database->open();
?>
<div class="container">
  <div style ="text-align:right; margin:20px 0px;">
    <!-- Button trigger indert modal -->
    <button type="button" class="btn btn-primary text-left" data-bs-toggle="modal" data-bs-target="#exampleModal">
    <span class="glyphicon glyphicon-plus"></span> Shto makine
    </button>
    <table class="table table-responsive">
      <thead>
        <tr>
          <th class="table-header">ID</th>
          <th class="table-header">Car Name</th>
          <th class="table-header">Production Year</th>
          <th class="table-header">Price</th>
          <th class="table-header">Currency</th>
          <th class="table-header">Transmission</th>
          <th class="table-header">Fuel</th>
          <th class="table-header">Actions</th>
        </tr>
      </thead>
      <tbody id="table-body">
      <?php 
          try {
             $sql = "SELECT * FROM cars ORDER BY id DESC";
             foreach($db->query($sql) as $row) {      
      ?>
        <tr class="table-row">
        <td><?php echo $row['id'];?></td>
          <td><?php echo $row['car_name'];?></td>
          <td><?php echo $row['year_production'];?></td>
          <td><?php echo $row['price'];?></td>
          <td><?php echo $row['currency'];?></td>
          <td><?php echo $row['transmission'];?></td>
          <td><?php echo $row['fuel'];?></td>
          <td>
            <a href="#edit_<?php echo $row['id']; ?>" class="btn btn-success btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-edit"></span> Ndrysho</a>
					  <a href="#delete_<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-trash"></span> Fshi</a>
          </td>
          <?php include('edit_delete_modal.php'); ?>
        </tr>
        <?php
              }
            }catch(PDOException $e){
              echo "Ka nje problem me lidhjen: " . $e->getMessage();
            }
            //close connection
            $database->close();
          ?>
      </tbody>
    </table>
  </div>
</div>

<div class="container">

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <form method="POST" action="insert.php">
            Car Name: <input class="form-control" type = "text" name="car_name" />
            Currency: <input class="form-control" type = "text" name="currency" />
            Transmission: <input class="form-control" type = "text" name="transmission" />
            Fuel: <input class="form-control" type = "text" name="fuel" />
            Price: <input class="form-control" type="number" name="price" />
            Year of Production: <input class="form-control" type="number" name="number" />       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="add_record" class="btn btn-primary">Shto Makine</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End insert modal -->
    
</div>

<?php
  include "footer.php";
?>

