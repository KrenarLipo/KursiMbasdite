<?php

include "header.php";

//Leksioni per ciklin For 
$arr1 = [2,6,8,10,12];  // var arr1 = [2,6,8,10,12];
$arr2 = [3,5,7,13,17];  // var arr2 = [3,5,7,13,17];

//cikli i pare for
echo "<p><center>";
foreach($arr1 as $t => $a){
    echo $t."=>".$a."</br>";
}
echo "<br>";
//cikli i dyte for
for($i=0; $i<sizeof($arr2); $i++){
    echo $arr2[$i]."<br>";
}
echo"</br>";
echo $arr2[3];  //console.log(arr2[3]);
$arr2[3] = 15;

/*
in javascript

if(ffff){

}else if(dicka tjeter){

}else{
    ffff
}
*/

if($arr2[3] < 15){
    echo "<br>Numri ".$arr2[3]." eshte me i vogel se 15";
}elseif($arr2[3] > 15){
    echo "<br>Numri ".$arr2[3]." nuk eshte me i vogel se 15";
}else{
    echo "<br>Numri ".$arr2[3]." eshte i barabarte me 15";
}
echo"</center></p>";

function getSum($t){
    
    $sum = $t + 1;
    return $sum;
}

$result = getSum(5);
echo $result;

/* === Regular expressions === */
$str = "Tirana ka zgjedhjet vendore 2021 Tirana 44 Tirana";
$pattern = "/Tirana/";  //RegEx i pare
echo "<br>";
echo "<center>";
//Afishon stringun kryesor
echo $str;
echo "<br>";
//Gjen sa Tirana kemi tek stringu $str edhe na kthen numrin
echo preg_match_all($pattern, $str);
echo "</center>";
echo "<br>";
echo"<center>";
//Nga stringu kryesor zevendesojme gjithe tiranat me shkodren
$str2 = preg_replace($pattern, "Shkoder", $str);
echo "<br>";
//Krijuam stringun e dyte nga zevendesimi i te parit
echo $str2;
echo "<br>";
//Zevendesojme ne stringun e dyte Shkodren me Durresin
echo preg_replace("/Shkoder/", "Durres", $str2);

/* ==== Punimet me datat ==== */
echo "<br><hr>";
echo date('Y/M/D');
echo "<br>";
echo date('y');
echo "<br>";
echo date("Y/M/D H:i");

