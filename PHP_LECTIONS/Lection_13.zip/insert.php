<?php
session_start();
include "header.php";
 
    if(isset($_POST["add_record"])){
        $database = new Connection();
		$db = $database->open();
        try {

            $stmt = $db->prepare("INSERT INTO cars (car_name, year_production, price, currency, transmission, fuel) VALUES(:car_name,:car_year,:car_price,:car_currency,:car_transmission,:car_fuel)");
    
            $_SESSION['message'] = ($stmt->execute(array(':car_name'=>$_POST['car_name'], ':car_year'=>$_POST['number'], ':car_price'=>$_POST['price'],
                                                    ':car_currency'=>$_POST['currency'], ':car_transmission'=>$_POST['transmission'], ':car_fuel'=>$_POST['fuel'])))?'Makina u shtua me sukses':'Pati nje problem ne shtim';
        }catch(PDOException $e) {
            $_SESSION['message'] = $e->getMessage();
        }
       //close connection
		$database->close();
    }else{
		$_SESSION['message'] = 'Fill up add form first';
	}
    
    header('location: index.php');
?>

