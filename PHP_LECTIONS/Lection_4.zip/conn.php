<?php

/* ==== Ketu do shkruhet kodi i lidhjes se Databases ==== */
$server = "localhost";
$user = "root";
$pass = "";


try{
    $dbh = new PDO("mysql:host=$server;dbname=php_connection",$user,$pass);
    
    //aktivizojme erroret
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //aktivizon errore dhe gjenerimi i mesazheve
    echo "Lidhja u krye me sukses";
}catch(PDOException $e){
    echo "Lidhja eshte gabim: " . $e->getMessage();
}