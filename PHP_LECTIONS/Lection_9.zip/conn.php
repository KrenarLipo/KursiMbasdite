<?php

Class Connection {
    
    /* ==== Ketu do shkruhet kodi i lidhjes se Databases ==== */
    private $server = "mysql:host=localhost;dbname=php_connection";
    private $user = "root";
    private $pass = "";
    private $options  = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,);
    protected $dbh;

    public function open(){
        try{
            $this->dbh = new PDO($this->server, $this->user, $this->pass, $this->options);
            return $this->dbh;
            //echo "Lidhja u krye me sukses";
        }catch(PDOException $e){
            echo "Lidhja eshte gabim: " . $e->getMessage();
        }
    }

    public function close(){
        $this->dbh = null;
    }
    
}
