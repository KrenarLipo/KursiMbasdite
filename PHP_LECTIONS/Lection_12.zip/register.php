<?php
session_start();
include "header.php";
?>
<div class="container">
    <div class="col-md-5">
    </div>
    <div class="col-md-7">
        <form action="addUser.php" method ="post">
        <div class="form-group">
            <label for="username">User Name:</label> 
            <input id="username" class="form-control" name="user-name" type="text" value="Shto Perdorues">
        </div>
        <div class="form-group">
            <label for="usersurname">User SurName:</label> 
            <input id="usersurname" class="form-control" name="user-surname" type="text" value="Shto Mbiemer">
        </div>
        <div class="form-group">
            <label for="useremail">User email:</label> 
            <input id="useremail" class="form-control" name="user-email" type="email" value="Jep email">
        </div>
        <div class="form-group">
            <label for="userpassword">User password:</label> 
            <input id="userpassword" class="form-control" name="user-password" type="password" value="Jepi password">
        </div>
        <div class="form-group">
            <label for="userphone">User phone:</label> 
            <input id="userphone" class="form-control" name="user-phone" type="text" value="Numer telefoni">
        </div>       
            <input class="btn btn-primary" name="add-user" type="submit" value="Shto perdorues">
        </form>
    </div>
</div>

