<?php
include "conn.php";

?>

<html>
<head>
    <title>Car's Management</title>
    <link rel="stylesheet" rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>