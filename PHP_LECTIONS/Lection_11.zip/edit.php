<?php
    session_start();
    include_once('header.php');

    if(isset($_POST['edit'])){
        $database = new Connection();
        $updatedb = $database->open();

        try {
            $id = $_GET['id'];
            $car_name = $_POST['car_name'];
            $car_price = $_POST['price'];
            $car_currency = $_POST['currency'];
            $car_year = $_POST['number'];
            $car_transmission = $_POST['transmission'];
            $car_fuel = $_POST['fuel'];

            $sql = "UPDATE cars SET car_name = '$car_name', year_production = '$car_year', 
                                    price = '$car_price', currency = '$car_currency',
                                    transmission = '$car_transmission', fuel = '$car_fuel'
                                    WHERE id = '$id' ";
             /*
               if($updatedb->exec($sql)){
                   echo "Makina u ndryshua me sukses";
               }else{
                   echo "Nuk mund te ndryshohet";
               }
            */
            $_SESSION['message'] = ($updatedb->exec($sql))? 'Makina u ndryshua me sukses':'Nuk mund te ndryshohet';

        }catch(PDOException $e){
            $_SESSION['message'] = $e->getMessage();
        }

        $database->close();

    }else{
        $_SESSION['message'] = "Mbush fushat qe mungojne";
    }

    header('location: index.php');