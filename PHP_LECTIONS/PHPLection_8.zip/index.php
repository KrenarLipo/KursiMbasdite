<?php 
include "header.php";
?>

<style>
  .wrapper {
      margin:10px auto;
      text-align: center;
      width:960px;
      padding:10px;
      border:1px solid #000;
  }
  .tbl-qa {
    width:100%;
    font-size:16px;
    background-color: #f5f5f5;
  }
  .tbl-qa th.table-header {
    padding:5px 10px;
    text-align:left;
  }
  .tbl-qa .table-row td{
    padding:10px;
    background-color: #FDFDFD;
    vertical-align: top;
    border:1px solid #000;
  }
  .button_link {
    color:#fff;
    text-decoration: none;
    background-color: #428a8e;
    padding:10px;
    float:left;
    margin:10px;
  }

</style>
<?php
  $pdo_statement = $dbh->prepare("SELECT * FROM cars ORDER BY id DESC");
  $pdo_statement->execute();
  $result = $pdo_statement->fetchAll();
?>
<div class="wrapper">
  <div style ="text-align:right; margin:20px 0px;">
    <a href="insert.php" class="button_link">Shto makine</a>
    <table class="tbl-qa">
      <thead>
        <tr>
          <th class="table-header">Car Name</th>
          <th class="table-header">Production Year</th>
          <th class="table-header">Price</th>
          <th class="table-header">Currency</th>
          <th class="table-header">Transmission</th>
          <th class="table-header">Fuel</th>
          <th class="table-header">ID</th>
        </tr>
      </thead>
      <tbody id="table-body">
      <?php 
          if(!empty($result)){
            foreach($result as $row) {
      ?>
        <tr class="table-row">
          <td><?php echo $row['car_name'];?></td>
          <td><?php echo $row['year_production'];?></td>
          <td><?php echo $row['price'];?></td>
          <td><?php echo $row['currency'];?></td>
          <td><?php echo $row['transmission'];?></td>
          <td><?php echo $row['fuel'];?></td>
          <td><?php echo $row['id'];?></td>
        </tr>
        <?php
            }
          }
          ?>
      </tbody>
    </table>
  </div>
</div>
<?php

// $emer_variabli = "Hello World!";

// $emer_variabli = "Hello Grupi!";

// $numri_fillestar = 3;

// /* Afishimi i variablit */

// echo '<div class="wrapper">';
// echo $emer_variabli." Teksti i ri."." ".($numri_fillestar+1); // emer_variabli + "Teksti i ri" per JS
// echo '</div>';

// $stmt = $dbh->query("SELECT * FROM `users`");
// $users = $stmt->fetchAll();
// echo "<pre>";
// print_r($users);
// echo"</pre>";

// /* ==== Metodat GET dhe Post ==== */
// $_GET['name'];
// $_POST['name'];
// // if($_GET["name"]||$_GET["age"]){
// //   echo "Welcome ".$_GET["name"]."<br/>";
// //   echo "You are ".$_GET["age"]." years old!";
// //   exit();
// // }
// if($_POST["name"]||$_POST["age"]){
//   if(preg_match("/[^A-Za-z]'-/",$_POST['name'])){
//     die("teksti eshte i gabuar");
//   }
//   echo "Welcome ".$_POST["name"]."<br/>";
//   echo "You are ".$_POST["age"]." years old!";
//   exit();
// }

// //$_REQUEST['name'];

// ?>

<!-- <form action = "<?php $_PHP_SELF ?>" method="post">
    Name: <input type = "text" name="name" />
    Age: <input type="text" name="age" />
   <input type="submit">
</form> -->