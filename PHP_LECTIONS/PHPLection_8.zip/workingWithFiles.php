
<style>
hr.redline {
    border-color:#f00;
}
</style>

<?php
include "header.php";

echo "<br/>";
echo readfile('shembull.txt');
echo "<hr><br/>";

//merr nje file vetem te lexueshem nga fillimi deri ne fund
$myfile = fopen('shembull.txt','r') or die("Nuk e hapim dot file-in");
echo fread($myfile, filesize('shembull.txt'));
fclose($myfile);

//Lexojme vetem rreshtin e pare t file-it
echo "<hr><br/>";
$myfile = fopen('shembull.txt','r') or die("Nuk e hapim dot file-in");
echo fgets($myfile);
fclose($myfile);

//Lexojme cdo resht deri ne fund te file-it
echo "<hr class='redline'><br/>";
$myfile = fopen('shembull.txt','r') or die("Nuk e hapim dot file-in");
while(!feof($myfile)){
    echo fgets($myfile)."<br><hr>";
}
fclose($myfile);

//Shkrimi tek file-et qe kemi deri tani
echo "<hr class='redline'><br/>";
$myfile = fopen('shembull.txt','w') or die("Nuk e hapim dot file-in");
//var_dump($myfile);
$tekst = "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

emer,mbiemer,mosha
Em1, Mb1, 30\n";
fwrite($myfile, $tekst);
$tekst = "<br> Kursi i Mbaasdites ATC";
fwrite($myfile, $tekst);
fclose($myfile);

?>

<form action="upload.php" method="post" enctype="multipart/form-data">
    <label>Select file to upload</label>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload file" name="submit">
</form>