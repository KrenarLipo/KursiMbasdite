<?php
include('header.php');
if(isset($_POST["user_id"])){
    $database = new Connection();
    $dbh = $database->open();
    $stmt = $dbh->prepare(
        "DELETE FROM users WHERE id = :id"
    );
    $result = $stmt->execute(
        array(
            ':id' => $_POST["user_id"]
        )
    );
    if(!empty($result)){
        echo "Data Deleted";
    }
}