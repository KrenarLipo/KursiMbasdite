<?php
session_start();
include "header.php";

?>
<div class="container">
<button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Add</button>
<div class="row">
    <h3>Userat tane</h3>
    <div class="table-responsive">
        <table id="user_data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Surname</th>
                    <th>Email</th>
                    <th>Phone</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="userModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Shtim Useri</h5>
        <button type="button" class="btn-close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
          <form method="POST" id="users_form">
            User Name: <input class="form-control" type = "text" name="username" id="username"/>
            User Surname: <input class="form-control" type = "text" name="surname" id="surname"/>
            User Email: <input class="form-control" type = "email" name="uemail" id="ueamil"/>
            User Password: <input class="form-control" type = "password" name="upassword" id="upassword"/>
            User Phone: <input class="form-control" type="text" name="uphone" id="uphone"/>  
      </div>
      <div class="modal-footer">
            <input type="hidden" name="user_id" id="user_id">;
            <input type="hidden" name="operation" id="operation">
            <input type="submit" name="action" id="action" class="btn btn-succes" value="Add"/>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End insert modal -->

</div>

<?php
include "footer.php";
?>

