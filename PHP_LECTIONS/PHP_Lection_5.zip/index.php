<?php 
include "header.php";
?>

<style>
  .wrapper {
      margin:0 auto;
      text-align: center;
      width:960px;
      padding:10px;
  }
</style>
<?php

$emer_variabli = "Hello World!";

$emer_variabli = "Hello Grupi!";

$numri_fillestar = 3;

/* Afishimi i variablit */

echo '<div class="wrapper">';
echo $emer_variabli." Teksti i ri."." ".($numri_fillestar+1); // emer_variabli + "Teksti i ri" per JS
echo '</div>';

$stmt = $dbh->query("SELECT * FROM `users`");
$users = $stmt->fetchAll();
echo "<pre>";
print_r($users);
echo"</pre>";

/* ==== Metodat GET dhe Post ==== */
$_GET['name'];
$_POST['name'];
// if($_GET["name"]||$_GET["age"]){
//   echo "Welcome ".$_GET["name"]."<br/>";
//   echo "You are ".$_GET["age"]." years old!";
//   exit();
// }
if($_POST["name"]||$_POST["age"]){
  if(preg_match("/[^A-Za-z]'-/",$_POST['name'])){
    die("teksti eshte i gabuar");
  }
  echo "Welcome ".$_POST["name"]."<br/>";
  echo "You are ".$_POST["age"]." years old!";
  exit();
}

//$_REQUEST['name'];

?>

<form action = "<?php $_PHP_SELF ?>" method="post">
   Name: <input type = "text" name="name" />
   Age: <input type="text" name="age" />
   <input type="submit">
</form>