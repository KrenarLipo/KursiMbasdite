<?php
session_start();
include "header.php";

$database = new Connection();
$db = $database->open();

if(isset($_POST["operation"] == "Add")){
    if($_POST["operation"] == "Add"){
        $stmt = $db->prepare("
            INSERT INTO users (username,surname,email,password,phone,role)
            VALUES (:username, :surname, :email,:password,:userphone, 2)  
        ");
        $result = $stmt->execute(
            array(
                ':username'=>$_POST["firstname"],
                ':surname'=>$_POST["surname"],
                ':email'=>$_POST["email"],
                ':password'=>$_POST["password"],
                ':userphone'=>$_POST["phone"]
                )
            );
            if(!empty($result)){
                echo "Data Inserted";
            }
        }
    }


?>