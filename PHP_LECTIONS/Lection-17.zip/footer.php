<?php 

//footer element

?>

</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript">
    $(document).ready(function(){
         var dataTable = $("#user_data").DataTable({
                "processing":true,
                "serverSide":true,
                "order": [],
                "ajax": {
                    url:"fetchUsers.php",
                    type: "POST",
                },
                columns: [
                    {
                        "name": "id",
                        "searchable":false,
                        "orderable":false
                    },
                    {
                        "name": "username",
                        "searchable":false,
                        "orderable":false
                    },
                    {
                        "name": "surname",
                        "searchable":false,
                        "orderable":false
                    },
                    {
                        "name": "email",
                        "searchable":false,
                        "orderable":false
                    },
                    {
                        "name": "phone",
                        "searchable":false,
                        "orderable":false
                    }
                ],
         }); //end of datatable inicialization
         
         //Hapja e javascriptit per insert
         $(document).on('submit', '#users_form', function(event){
             event.preventDefault();
             var firstname = $('#username').val();
             var surname = $('#surname').val();
             var email = $('#ueamil').val();
             var password = $('#upassword').val();
             var phone = $('#uphone').val();
             if(firstname!=''&&email!=''&&password!=''&&phone!=''){
                 $.ajax({
                     url: "add_new_user.php",
                     method :"POST",
                     data : new FormData(this),
                     contentType: false,
                     processData: false,
                     success:function(data){
                        alert(data);
                        $('#users_form')[0].reset();
                        $('#userModal').modal('hide');
                        dataTable.ajax.reload();
                     }
                 });
             }else{
                 alert("All the fields with star are Required");
             }
         });
         
         

    });
</script>

</html>