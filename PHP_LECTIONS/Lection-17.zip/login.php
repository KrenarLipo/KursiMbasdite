<?php
session_start();
include "header.php";
/* ==== Kodi per logimin ne faqen tone ==== */
  $login_error_message = '';
  $register_error_messagge ='';
  if(isset($_POST['login-user'])){
    if(!empty($_POST["username"])&&!empty($_POST['password'])){

      $thepassword = password_hash($_POST["password"],PASSWORD_DEFAULT);

      $databaselogin = new Connection();
      $db = $databaselogin->open();

      try {

        $stmt = $db->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
        
        $count = $stmt->rowCount();
        if($count>0){
          $_SESSION["username"] = $_POST["username"];
          header('location: listoMakinat.php');
        }else{
          header('location: login.php');
        }
      }catch(PDOException $e) {
        $_SESSION['message'] = "Ka nje problem me userin: " . $e->getMessage();
      }
      //close connection
		  $db = $databaselogin->close();
    }
  }else{
    $login_error_message = "Mungojne te dhenat ne login!";
  }

?>
<div class="container-fluid imazhaboutus">
    <h2><a href="ForgotPassword.php">Harrova Passwordin</a></h2>
</div>
<div class="container">
    <div class="col-md-3">
    <?php
        if(isset($login_error_message)){
            echo '<label class="">'.$login_error_message.'</label>';
        }
    ?>
    </div>
    <div class="col-md-6">
        <form method ="post">
        <div class="form-group">
            <label for="username">Username:</label> 
            <input id="username" class="form-control" name="username" type="text" value="">
        </div>
        <div class="form-group">
            <label for="userpassword">User password:</label> 
            <input id="userpassword" class="form-control" name="password" type="password" value="">
        </div>      
            <input class="btn btn-primary" name="login-user" type="submit" value="Logohuni">
        </form>
    </div>
    <div class="col-md-3">
    </div>
</div>


