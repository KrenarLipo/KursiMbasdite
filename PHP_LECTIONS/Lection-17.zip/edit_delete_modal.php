<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Ndrysho Makine</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="edit.php?id=<?php echo $row['id']; ?>">
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Car Name:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="car_name" value="<?php echo $row['car_name']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Production year:</label>
					</div>
					<div class="col-sm-8">
						<input type="number" class="form-control" name="number" value="<?php echo $row['year_production']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Price:</label>
					</div>
					<div class="col-sm-8">
						<input type="number" class="form-control" name="price" value="<?php echo $row['price']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Currency:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="currency" value="<?php echo $row['currency']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Transmission:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="transmission" value="<?php echo $row['transmission']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label" style="position:relative; top:7px;">Fuel Type:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="fuel" value="<?php echo $row['fuel']; ?>">
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-success"><span class="glyphicon glyphicon-check"></span>Perditeso</a>
			</form>
            </div>

        </div>
    </div>
</div>

<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Fshi Makinen</h4></center>
            </div>
            <div class="modal-body">	
            	<p class="text-center">Jeni i sigurte qe deshironi ta fshini makinen?</p>
				<h2 class="text-center"><?php echo $row['car_name'].' te vitit '.$row['year_production']; ?></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Jo mos fshi</button>
                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Po Fshih</a>
            </div>

        </div>
    </div>
</div>