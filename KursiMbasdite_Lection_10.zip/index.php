<?php include "header.php"; ?>

<body>
<div class="container-fluid">

                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>

                    <!-- slided perkatese -->
                    <div class="carousel-inner" roles="listbox">
                        <div class="item active">
                            <img src="img/slide_one.jpg" alt="Ky eshte Alti 0">
                            <div class="carousel-caption">
                                <h3>Slide 1</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="item">
                            <img src="img/slide_two.jpg" alt="Ky eshte Alti 1">
                            <div class="carousel-caption">
                                <h3>Slide 2</h3>
                                <p>
                                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
                                </p>
                                
                            </div>
                        </div>
                        <div class="item">
                            <img src="img/slide_three.jpg" alt="Ky eshte Alti 2">
                            <div class="carousel-caption">
                                <h3>Slide 3</h3>
                                <p>
                                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                </p>
                                
                            </div>
                        </div>
                    </div>

                    <!-- Controls/Shigjetat e Slide-it --> 
                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Pas</span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Para</span>
                    </a>

                </div>
            </div>

            <div class="clearfix"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-5">
                        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4 col-md-offset-2">
                        <img class="img-responsive" src="img/imazh.jpg" />
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-1">
                        <button class="btn btn-success" id="vlereNumerike" onclick="ktheNumrin(5)">Shiko vleren</button>
                        <button class="btn btn-success" id="diten" onclick="gjejDiten()">Kthe diten</button>
                    </div>
                    <!-- Tabela me bordera -->
                    <br>
                    <div class="col-md-12 mt-10">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="col-md-2">ID</th>
                                    <th class="col-md-3">Emri</th>
                                    <th class="col-md-3">Mbiemri</th>
                                    <th class="col-md-3">Emaili</th>
                                </tr>                            
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="col-md-2">1</td>
                                    <td class="col-md-3">John</td>
                                    <td class="col-md-3">Hasber</td>
                                    <td class="col-md-3">john.hasber@yahoo.com</td>
                                </tr>
                                <tr>
                                    <td class="col-md-2">2</td>
                                    <td class="col-md-3">Mat</td>
                                    <td class="col-md-3">Mila</td>
                                    <td class="col-md-3">mm@gmail.com</td>
                                </tr>
                                <tr>
                                    <td class="col-md-2">3</td>
                                    <td class="col-md-3">Lebron</td>
                                    <td class="col-md-3">James</td>
                                    <td class="col-md-3">lebron@gmail.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

<?php include "footer.php"; ?>


