/* Fjala kyce var mund te jete:
   1. Numer => si numer shenohet  var nr = 1
   2. Tekst => si tekst shenohet var txt = 'Une jam tekst'
   3. Array => si tabele do shenohet var tabela = [];
*/
var numri_one = 3;
var txt = 'Une jam numri ';

//console.log(txt+''+(numri_one+3));

numri_one = 4;

console.log(txt+''+numri_one);

var numri_dy = 5;
var shtojca;

/* function,  
    EmerFunksioni,
     kllapa rrethore me ose pa variabla 
      kllapa gjarperueshe hapese edhe mbyllese */

function ktheNumrin(shtojca){

   /* fjala kyce if
      me pas kllapa rrethore hapese mbyllese
      me pas kllapa gjarperuese mbyllese hapese
      ne fund else 
   */

   if(shtojca >= 3 && shtojca<4){
     console.log("Me e madhe ose baraz 3");
   }else if(shtojca < 5 && shtojca >3){
     console.log("Vlera 4") ;   
   }else{
      console.log("Vlere Tjeter");
   }
  //console.log("une jam numri: "+shtojca);
}

console.log(new Date().getDay());

function gjejDiten(){
   var day;
   switch(new Date().getDay()){
      case 0:
         day="Sunday";
         break;
      case 1:
         day = "Monday";
         break;
      case 2:
         day = "Tuesday";
         break;
      case 3:
         day = "Wensday";
         break;
      case 4:
         day = "Thursday";
   }
   console.log(day);
}



//jQuery('.carousel').carousel();