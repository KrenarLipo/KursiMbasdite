//console.log("Une jam javascript");
console.log('Une jam javascript');
/*
console.log("Une jam javascript");
*/

jQuery('.carousel').carousel();