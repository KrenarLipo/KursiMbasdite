<?php include "header.php"; ?>

<body>
<div class="container-fluid imazhaboutus">
   <h4>Faqja Rreth Nesh</h4>
</div>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-3 m-10">
            <button class="btn btn-success" onclick="gjejMin()">Shfaq Min</button>
            <button class="btn btn-primary" ondblclick="gjeMax()">Shfaq Max</button>
            <button class="btn btn-info" onclick="afishoObjekt()">Afisho Personin</button>
            <button class="btn btn-warning" onclick="afishoObjektFor()">Afisho Deputetet</button>
            <button class="btn btn-danger" onclick="objektJson()">Objekti</button>
        </div>
        <div class="col-xs-12 col-md-2 m-10">
            <p id="minimumi"></p>
            <p id="maksimumi"></p>
            <p id="studenti"></p>
            <p id="deputeti"></p>
        </div>
        <div class="col-xs-12 col-md-2 m-10">
             <p id="simpletext">
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
             when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
             It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
             It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
             and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
             </p>
             <button id="fsheh_text" class="btn btn-info">Fshi tekstin me siper</button>
             <button id="rishfaq_tekst" class="btn btn-success hidden">Rishfaq Tekst</button>
        </div>
    </div>
</div>


<?php include "footer.php"; ?>