<?php include "header.php"; ?>

<body>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-5">
            <h2>Kliko Button</h2>
            <button id="modifikuesi" class="btn btn-warning">Vepro</button>
            <button id="luajAjax" class="btn btn-default">Starto Ajax</button>
            <button id="luajAjaxMSG" class="btn btn-primary">Starto</button>
        </div>
        <div class="col-xs-12 col-md-5 tekstIM">
             <h2>Teksti ku do modifikojme</h2>
             <p>Paragraf i thjeshte</p>
             <span>Some text</span>
             <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, 
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset 
                sheets containing Lorem Ipsum passages, and more recently with desktop publishing 
                software like Aldus PageMaker including versions of Lorem Ipsum.
             </p>
        </div>
        <div class="col-xs-12 col-md-2 ajaxResult">
            <p>Teksti Aktual</p>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>