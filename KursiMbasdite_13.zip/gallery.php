<?php include "header.php"; ?>

<body>

<div class="container-fluid imazhgalerie">
   <h4>Faqja e Galerise</h4>
</div>

<div class="container m-10">
    <div class="row">
        <div class="col-xs-12 col-6 col-md-4">
            <div class="img-hover-zoom">
				<img class="img-fluid" src="img/london-view.jpg">
			</div>
        </div>
        <div class="col-xs-12 col-6 col-md-4">
            <div class="img-hover-fastzoom">
				<img class="img-fluid" src="img/campus-tour.jpg">
			</div>
        </div>
        <div class="col-xs-12 col-6 col-md-4"></div>
        <div class="col-xs-12 col-6 col-md-4"></div>
        <div class="col-xs-12 col-6 col-md-4"></div>
        <div class="col-xs-12 col-6 col-md-4"></div>
    </div>
    
</div>

<?php include "footer.php"; ?>