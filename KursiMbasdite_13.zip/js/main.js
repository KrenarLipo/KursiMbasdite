/* Fjala kyce var mund te jete:
   1. Numer => si numer shenohet  var nr = 1
   2. Tekst => si tekst shenohet var txt = 'Une jam tekst'
   3. Array => si tabele do shenohet var tabela = [];
*/
var numri_one = 3;
var txt = 'Une jam numri ';

//console.log(txt+''+(numri_one+3));

numri_one = 4;

console.log(txt+''+numri_one);

var numri_dy = 5;
var shtojca;

/* function,  
    EmerFunksioni,
     kllapa rrethore me ose pa variabla 
      kllapa gjarperueshe hapese edhe mbyllese */

function ktheNumrin(shtojca){

   /* fjala kyce if
      me pas kllapa rrethore hapese mbyllese
      me pas kllapa gjarperuese mbyllese hapese
      ne fund else 
   */

   if(shtojca >= 3 && shtojca<4){
     console.log("Me e madhe ose baraz 3");
   }else if(shtojca < 5 && shtojca >3){
     console.log("Vlera 4") ;   
   }else{
      console.log("Vlere Tjeter");
   }
  //console.log("une jam numri: "+shtojca);
}

console.log(new Date().getDay());

function gjejDiten(){
   var day;
  
   switch(new Date().getDay()){
      case 0:
         day="Sunday";
         break;
      case 1:
         day = "Monday";
         break;
      case 2:
         day = "Tuesday";
         break;
      case 3:
         day = "Wednesday";
         break;
      case 4:
         day = "Thursday";
   }
   console.log(day);
}


// for(var i = 1; i<=10000; i++){
//    console.log(i);
// }

//var_one + '' + var_two;

function getAllData() {
   /* indekset = 0 ======= 1 ======== 2 ===== 3 ===== */
   //var cars = ["BMW", "MERCEDEZ", "TOYOTA", "GOLF"];
   var numrat = [1,3,5,8,9,10,12];
   var res = [];
   var nores = [];

   console.log(numrat[0]);

   for(var j=0; j<numrat.length; j++){
      if(numrat[j]<10){
         res.push(numrat[j]);
      }else{
         nores.push(numrat[j]);
      }
   }

   for(var k=0; k<res.length; k++){  // cars.length == i < 4
      document.getElementById('result').innerHTML += res[k]+'<br>'; // i-ja ketu merr vlerat nga 0 -> 3
      /* ==== gjeme id-ne result ne html ======== tek stringu kryesor shtojme cdo element te i */
   }

   console.log(nores)
   document.getElementById('result').innerHTML+='<p>Kemi gjithsej: <span class="redcolor">'+ nores.length + '</span> elemente te barabarte ose me te medhenj se 10</p>';
}

function perdorWhile(){
   var text="";
   var i = 1;
   while(i<=10){
      text +="<br>Numri eshte: "+i;
      i++;
   }
   document.getElementById('result').innerHTML += text;
}


//jQuery('.carousel').carousel();