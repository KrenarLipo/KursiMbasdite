/* Fjala kyce var mund te jete:
   1. Numer => si numer shenohet  var nr = 1
   2. Tekst => si tekst shenohet var txt = 'Une jam tekst'
   3. Array => si tabele do shenohet var tabela = [];
*/
var numri_one = 3;
var txt = 'Une jam numri ';

//console.log(txt+''+(numri_one+3));

numri_one = 4;

console.log(txt+''+numri_one);

var numri_dy = 5;
var shtojca;
var mixedArray = ["Makina",2020,"COVID",19];
console.log(mixedArray);

/* function,  
    EmerFunksioni,
     kllapa rrethore me ose pa variabla 
      kllapa gjarperueshe hapese edhe mbyllese */

function ktheNumrin(shtojca){

   /* fjala kyce if
      me pas kllapa rrethore hapese mbyllese
      me pas kllapa gjarperuese mbyllese hapese
      ne fund else 
   */

   if(shtojca >= 3 && shtojca<4){
     console.log("Me e madhe ose baraz 3");
   }else if(shtojca < 5 && shtojca >3){
     console.log("Vlera 4") ;   
   }else{
      console.log("Vlere Tjeter");
   }
  //console.log("une jam numri: "+shtojca);
}

console.log(new Date().getDay());

function gjejDiten(){
   var day;
  
   switch(new Date().getDay()){
      case 0:
         day="Sunday";
         break;
      case 1:
         day = "Monday";
         break;
      case 2:
         day = "Tuesday";
         break;
      case 3:
         day = "Wednesday";
         break;
      case 4:
         day = "Thursday";
   }
   console.log(day);
}


// for(var i = 1; i<=10000; i++){
//    console.log(i);
// }

//var_one + '' + var_two;
function shfaqTest(){
   var result = "Test";
   return result;
}

function NoTest(){
   var result = "No Test";
   return result;
}

var testing = [2, 5];

for(var j=0; j<testing.length; j++){
   
    if(j=0){
      shfaqTest();
    }else if(j=1){
      NoTest();
    }
}

function getAllData() {
   /* indekset = 0 ======= 1 ======== 2 ===== 3 ===== */
   var cars = ["BMW", "MERCEDEZ", "TOYOTA", "GOLF"];
   var numrat = [1,3,5,8,9,10,12];
  
   var res = [];
   var nores = [];

   //console.log(cars[1]); // key ne array esthte indexi dhe value eshte vlera poshte indeksit
   console.log(cars[0]);
   console.log(numrat[1]);
  

   for(var k=0; k<res.length; k++){  // cars.length == i < 4
      document.getElementById('result').innerHTML += res[k]+'<br>'; // i-ja ketu merr vlerat nga 0 -> 3
      /* ==== gjeme id-ne result ne html ======== tek stringu kryesor shtojme cdo element te i */
   }

   console.log(nores)
   document.getElementById('result').innerHTML+='<p>Kemi gjithsej: <span class="redcolor">'+ nores.length + '</span> elemente te barabarte ose me te medhenj se 10</p>';
}

function perdorWhile(){
   var text="";
   var i = 1;
   while(i<=10){
      text +="<br>Numri eshte: "+i;
      i++;
   }
   document.getElementById('result').innerHTML += text;
}

var a,b;
a = 100;
b = 50;
var c = 2;
var d = 3;
var e = 64;
console.log(a+b);
console.log(a - b);
console.log((a+b)*c);
console.log((a+b)/d); 
console.log(Math.abs(b-a));
console.log(Math.sqrt(e));
console.log(Math.sin(90*Math.PI/180));
//jQuery('.carousel').carousel();

/* ==== funksione qe kane lidhje me libraririne Math ==== */
function gjejMin(){
   document.getElementById("minimumi").innerHTML = Math.min(4,12,5,1,0,-2);
}

function gjeMax(){
   document.getElementById("maksimumi").innerHTML = Math.max(4,12,5,1,0,-2);
}

/* ==== Funksion per afishimin e diteve te javes === */
function shfaqDiteJave() {
   var ditJave = ["Mon", "Tue", "Wen", "Thur", "Fri", "Sat", "Sun"]; //array i diteve te javes
    // vlera e marre nga input fieldi
   var cel = $('#celesi').val();
   for(var i=0; i < ditJave.length; i++){
      if( i = cel){
         document.getElementById("ditjave").innerHTML = ditJave[cel];
         break;
      }else if(cel!=1){
         document.getElementById("ditjave").innerHTML += ditJave[i]+"<br>";
      }
      
   }
}

/* ==== Afishimi i nje objekti ne menyre te thjeshte ==== */
function afishoObjekt() {
   var student = {
      emri: "Ervin",
      mbiemri: "Duka",
      notaMesatare: 7.6,
      mosha: 20,
      klasa: "4B"
   };
   
   document.getElementById("studenti").innerHTML = student.emri + " " + student.mbiemri +"" + " ka note mesatare: " + student.notaMesatare;
   
}

/* ==== Afishimi i objektit kompleks me cikel for ==== */
function afishoObjektFor() {
   var deputetet = {
         Deputet_one: {
            emri: "Edi",
            mbiemri: "Rama",
            profesioni: "Piktor",
            partia: "PS"
         },
         Deputet_two: {
            emri:"Sali",
            mbiemri:"Berisha",
            profesioni: "Doktor",
            partia:"PD"
         },
         Deputet_three: {
            emri: "Monika",
            mbiemri:"Kryemadhi",
            profesioni: "Prima donna",
            partia: "LS_I"
         }
      };

      for(var i in deputetet){
         [].concat(deputetet[i].emri+': '+deputetet[i].mbiemri).forEach(function(emmb){
            document.getElementById("deputeti").innerHTML += ""+emmb+"<br>";
         });  //deputet[Deputet_one], deputetet[Deputet_two], deputetet[Deputet_three]
      }
}

/* ===== Funksioni per konvertimin e JSONIT ne String ===== */
function objektJson() {

   var studenti = {
      "emri":"Artan",
      "mbiemri": "Nikolla",
      "klasa": "4B",
      "mosha":21,
      "profili": "Master_Shkencor"
   };

   var result = JSON.stringify(studenti);

   window.location = "testingJson.php?s="+ result;

}

function riktheObjekt() {
   var res = window.location.search;
   console.log(res);
   //var res = JSON.parse(s);
   //document.getElementById("objekti").innerHTML = ""+res.emri+": "+res.mbiemri+" =>"+res.profili;
}

function filloAnimim() {
   $('#animation_start').click(function(){
      $('#katror_one').fadeIn(3000);
      $('#katror_dy img').fadeOut(3000);
      $('#katror_tre').fadeTo(3000, 0.5);
      $('#katror_kater').fadeToggle(3000);
   });
}

function dropdownPanel(){
   $('#dropdownpanel').click(function(){
      $('#panel').slideDown("slow");
   });
}

function moveLeft(){
   $('#translateleft').click(function(){
      $('.katroriMagjik').animate(
         {
            left:'+=300px',
            width:'+=50px',
            height:'+=50px'      
         }, 2000);
   });
}

function moveRight(){
   $('#translateright').click(function(){
      $('.katroriMagjik').animate(
         {
            left:'-=300px',
            width:'-=50px',
            height:'-=50px'
         }, 3000);
    });
}

function afishoEmailFname(){
   var emri = $('#fname').val();
   var emaili = $('#myemail').val();
   if(emri!=null && emaili!=null){
      document.getElementById("resultati").innerHTML = " ";
      document.getElementById("resultati").innerHTML += ""+emri+" :"+emaili+"";
   }else{
      document.getElementById("resultati").innerHTML += ""+emri+" :"+emaili+"";
   }
  
}

function shtoTekstPas(){
   $('.pasP').click(function(){
      $('.vendi_punes').append(' PAS');
   });
}

function shtoTekstPara(){
   $('.paraP').click(function(){
      $('.vendi_punes').prepend('PARA ');
   });
}

function shtoTekstParaSpan(){
   $('.beforeP').click(function(){
      $('.vendi_punes span').before('BEFORE ');
   });
}

function shtoTekstPasSpan(){
   $('.afterP').click(function(){
      $('.vendi_punes span').after(' AFTER');
   });
}

function testDanger(){
   $('.testString').click(function(){
      $('.test_string').find('Testim ').after(' TTTTT');
   });
}

function ngjyrosParagrafin() {
   $('#modifikuesi').click(function(){
      $('div').find('div.tekstIM').find('h2').addClass('redcolor');
   });
}

function merrTeDhenaTeJashtme(){
   $('.ajaxResult').load('dokumenti.txt h2');
}


$(document).ready(function(){
       
    $('#emer_id');  //document.getElementByID('emer_id')
    $('.emer_klase');

    $('#fsheh_text').click(function (){
      $('#simpletext').hide();
      $('#rishfaq_tekst').removeClass('hidden');
    });

    $('#rishfaq_tekst').click(function(){
      $('#simpletext').show();
      $('#rishfaqtekst').addClass('hidden');
    
    });


    $('#simpletext').mouseenter(function(){
         $(this).addClass('nxi_germat');
      $(this).fadeOut(700)
      .fadeIn(700)
      .css("color", "blue")
    });


    $('#simpletext').mouseleave(function(){
      $(this).removeClass('nxi_germat');
   });

   filloAnimim();
   dropdownPanel();
   moveLeft();
   moveRight();

   $('#shfaqInfo').click(function(){
      afishoEmailFname();
   });
   
   shtoTekstPas();
   shtoTekstPara();
   shtoTekstParaSpan();
   shtoTekstPasSpan();
   testDanger();
   ngjyrosParagrafin();

   $('#luajAjax').click(function(){
      merrTeDhenaTeJashtme();
   });

   $('#luajAjaxMSG').click(function(){
      $('.ajaxResult').load('dokumentit.txt h2', function(responseTXT, statusTXT, xhr){
         if(statusTXT == "success")
            alert("I Sukseshem");
         if(statusTXT == "error")
          alert("Error: " +xhr.status+""+xhr.statusTXT);
      });
   });


});










