<section id="footer">
 <div class="container-fluid myFooter">
    <div class="container">
        <div class="col-xs-12 col-6 col-md-3">
            <h4>Rights</h4>
            &copy; Copyright for Kursi Mbasdite
        </div>
        <div class="col-xs-12 col-6 col-md-3">
            <h4>Contact Us</h4>
            <b>Number: </b> 3556969777
            <br>
            <b>Email: </b><a href="mailto:klipo90@gmail.com">Kursi Mbasdite</a>
        </div>
        <div class="col-xs-12 col-6 col-md-3">
            <h4>Menu</h4>
            <nav class="navbar">
                <ul class="nav navbar-nav"> 
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">Rreth Nesh</a></li>
                    <li><a href="contact.php">Kontakti</a></li>
                </ul>      
            </nav>
        </div>
        <div class="col-xs-12 col-6 col-md-3">
            <h4>Return Top</h4>
            <a href="#header" class="arrowTop">Go Up </a>
        </div>
    </div>
 </div>
</section>

</body>

<script src="js/jquery.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
<script src="js/main.js"></script>

</html>