<?php include "header.php"; ?>

<body>
<div class="contianer">
    <div class="row">
        <div class="col-xs-12 col-md-6">
            <button class="btn btn-success" onclick="shfaqDiteJave()">Shfaq Min</button>
            <input type="number" id="celesi" />
        </div>
        <div class="col-xs-12 col-md-6">
            <p id="ditjave"></p>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>