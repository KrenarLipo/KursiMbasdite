//console.log("Une jam javascript");
console.log('Une jam javascript');
/*
console.log("Une jam javascript");
*/