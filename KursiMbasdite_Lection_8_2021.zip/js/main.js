/* Fjala kyce var mund te jete:
   1. Numer => si numer shenohet  var nr = 1
   2. Tekst => si tekst shenohet var txt = 'Une jam tekst'
   3. Funksion => si funksion do shenohet var f = emerFunksioni()
*/
var numri_one = 3;
var txt = 'Une jam numri ';
//var f = function();

console.log(txt+''+(numri_one+3));

//jQuery('.carousel').carousel();