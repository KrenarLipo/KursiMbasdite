<?php include "header.php"; ?>

<body>
<div class="container">
    <div class="row">
    <!-- Animim 1 -->
    <center>
        <button class="btn btn-success" id="animation_start">Fillo animim</button>
    </center>
    <br>
        <div class="col-md-3">
            <div class="retangle_one" id="katror_one"></div>
        </div>  
        <div class="col-md-3">
            <div class="retangle_two" id="katror_dy"><img src="img/nature.jpg" width="100" height="100"></div>
        </div> 
        <div class="col-md-3">
            <div class="retangle_three" id="katror_tre"></div>
        </div> 
        <div class="col-md-3">
            <div class="retangle_four" id="katror_kater"></div>
        </div> 
        <div class="clearfix"></div>
        <div id="dropdownpanel">Klikoni per te pare me poshte</div> 
        <div id="panel">Paneli i tekstit</div> 
    </div>
</div>
<div class="clearfix"></div>
<div class="container" style="margin-bottom:120px;">
    <div class="row">
        <button class="btn btn-info" id="translateleft">></button>
        <button class="btn btn-info" id="translateright"><</button>
        <div class="col-xs-12 col-md-10">
            <div class="katroriMagjik"></div>
        </div>
    </div>
</div>
<div class="clearfix" ></div>
<?php include "footer.php"; ?>