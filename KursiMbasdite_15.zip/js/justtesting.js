if(expression = x){
    //do something
}else if(expression = y){
  //do something
}else{
  expression = "default";
}