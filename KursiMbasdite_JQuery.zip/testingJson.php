<?php include "header.php"; ?>

<body>
<div class="container">
    <div class="row">
        <h4>Jemi tek faqja e testimeve</h4>
        <div class="col-xs-12 col-md-4">
            <button class="btn btn-primary" onclick="riktheObjekt()">Rikthe Objekt</button>
        </div>
        <div class="col-xs-12 col-md-6 col-md-offset-2 ">
            <p id="objekti"></p>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>