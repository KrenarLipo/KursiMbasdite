<?php include "header.php"; ?>

<body>
<div class="container-fluid imazhaboutus">
   <h4>Faqja Rreth Nesh</h4>
</div>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-3 m-10">
            <button class="btn btn-success" onclick=" gjejMin()">Shfaq Min</button>
            <button class="btn btn-success" ondblclick="gjeMax()">Shfaq Max</button>
            <button class="btn btn-info" onclick="afishoObjekt()">Afisho Personin</button>
            <button class="btn btn-info" onclick="afishoObjektFor()">Afisho Deputetet</button>
        </div>
        <div class="col-xs-12 col-md-2 m-10">
            <p id="minimumi"></p>
            <p id="maksimumi"></p>
            <p id="studenti"></p>
            <p id="deputeti"></p>
        </div>
    </div>
</div>


<?php include "footer.php"; ?>