<?php include "header.php"; ?>

<body>
    <div class="container">
        <form action="shto.php" method="get">
            <label for="fname">First name:</label><br>
            <input type="text" id="fname" name="fname" required><br>
            <label for="lname">Last name:</label><br>
            <input type="text" id="fname" name="fname"><br>
            <label for="myemail">Email:</label><br>
            <input type="email" id="myemail" name="myemail" placeholder="Email" required><br>
            <label for="selecting">Perzgjidh:</label><br>
            <select id="selecting">
                <option>element 1</option>
                <option>element 2</option>
                <option>element 3</option>
            </select> 
            <br> 
            <label for="mesazhi">Mesazh:</label><br>
            <textarea id="mesazhi" name="mesazhi"></textarea><br>
            <label for="mycheckbox">Checkbox:</label><br>
            <input type="checkbox" name="mycheckbox" id="mycheckbox" value="Vehicle 1"><br>
            <label for="year">Viti:</label><br>
            <input type="number" id="year" name="year"><br><br>
            <input type="submit" value="Submit">
        </form>
    </div>


<?php include "footer.php"; ?>