<?php 

/// The code here

?>

<!--- html code -->

<?php 

?>