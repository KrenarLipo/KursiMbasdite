/* Fjala kyce var mund te jete:
   1. Numer => si numer shenohet  var nr = 1
   2. Tekst => si tekst shenohet var txt = 'Une jam tekst'
   3. Array => si tabele do shenohet var tabela = [];
*/
var numri_one = 3;
var txt = 'Une jam numri ';

//console.log(txt+''+(numri_one+3));

numri_one = 4;

console.log(txt+''+numri_one);

var numri_dy = 5;
var shtojca;

/* function,  
    EmerFunksioni,
     kllapa rrethore me ose pa variabla 
      kllapa gjarperueshe hapese edhe mbyllese */

function ktheNumrin(shtojca){

   /* fjala kyce if
      me pas kllapa rrethore hapese mbyllese
      me pas kllapa gjarperuese mbyllese hapese
      ne fund else 
   */

   if(shtojca >= 3 && shtojca<4){
     console.log("Me e madhe ose baraz 3");
   }else if(shtojca < 5 && shtojca >3){
     console.log("Vlera 4") ;   
   }else{
      console.log("Vlere Tjeter");
   }
  //console.log("une jam numri: "+shtojca);
}

console.log(new Date().getDay());

function gjejDiten(){
   var day;
  
   switch(new Date().getDay()){
      case 0:
         day="Sunday";
         break;
      case 1:
         day = "Monday";
         break;
      case 2:
         day = "Tuesday";
         break;
      case 3:
         day = "Wednesday";
         break;
      case 4:
         day = "Thursday";
   }
   console.log(day);
}


// for(var i = 1; i<=10000; i++){
//    console.log(i);
// }

//var_one + '' + var_two;

function getAllData() {
   /* indekset = 0 ======= 1 ======== 2 ===== 3 ===== */
   //var cars = ["BMW", "MERCEDEZ", "TOYOTA", "GOLF"];
   var numrat = [1,3,5,8,9,10,12];
   var res = [];
   var nores = [];

   console.log(numrat[0]);

   for(var j=0; j<numrat.length; j++){
      if(numrat[j]<10){
         res.push(numrat[j]);
      }else{
         nores.push(numrat[j]);
      }
   }

   for(var k=0; k<res.length; k++){  // cars.length == i < 4
      document.getElementById('result').innerHTML += res[k]+'<br>'; // i-ja ketu merr vlerat nga 0 -> 3
      /* ==== gjeme id-ne result ne html ======== tek stringu kryesor shtojme cdo element te i */
   }

   console.log(nores)
   document.getElementById('result').innerHTML+='<p>Kemi gjithsej: <span class="redcolor">'+ nores.length + '</span> elemente te barabarte ose me te medhenj se 10</p>';
}

function perdorWhile(){
   var text="";
   var i = 1;
   while(i<=10){
      text +="<br>Numri eshte: "+i;
      i++;
   }
   document.getElementById('result').innerHTML += text;
}

var a,b;
a = 100;
b = 50;
var c = 2;
var d = 3;
var e = 64;
console.log(a+b);
console.log(a - b);
console.log((a+b)*c);
console.log((a+b)/d);
console.log(Math.abs(b-a));
console.log(Math.sqrt(e));
console.log(Math.sin(90*Math.PI/180));
//jQuery('.carousel').carousel();

/* ==== funksione qe kane lidhje me libraririne Math ==== */
function gjejMin(){
   document.getElementById("minimumi").innerHTML = Math.min(4,12,5,1,0,-2);
}

function gjeMax(){
   document.getElementById("maksimumi").innerHTML = Math.max(4,12,5,1,0,-2);
}

/* ==== Afishimi i nje objekti ne menyre te thjeshte ==== */
function afishoObjekt() {
   var student = {
      emri: "Ervin",
      mbiemri: "Duka",
      notaMesatare: 7.6,
      mosha: 20,
      klasa: "4B"
   };
   
   document.getElementById("studenti").innerHTML = student.emri + " " + student.mbiemri +"" + " ka note mesatare: " + student.notaMesatare;
}

/* ==== Afishimi i objektit kompleks me cikel for ==== */
function afishoObjektFor() {
   var deputetet = {
         Deputet_one: {
            emri: "Edi",
            mbiemri: "Rama",
            profesioni: "Piktor",
            partia: "PS"
         },
         Deputet_two: {
            emri:"Sali",
            mbiemri:"Berisha",
            profesioni: "Doktor",
            partia:"PD"
         },
         Deputet_three: {
            emri: "Monika",
            mbiemri:"Kryemadhi",
            profesioni: "Prima donna",
            partia: "LS_I"
         }
      };

      for(var i in deputetet){
         [].concat(deputetet[i].emri+': '+deputetet[i].mbiemri).forEach(function(emmb){
            document.getElementById("deputeti").innerHTML += ""+emmb+"<br>";
         });  //deputet[Deputet_one], deputetet[Deputet_two], deputetet[Deputet_three]
      }
}

/* ===== Funksioni per konvertimin e JSONIT ne String ===== */
function objektJson() {

   var studenti = {
      "emri":"Artan",
      "mbiemri": "Nikolla",
      "klasa": "4B",
      "mosha":21,
      "profili": "Master_Shkencor"
   };

   var result = JSON.stringify(studenti);

   window.location = "testingJson.php?s="+ result;

}

function riktheObjekt() {
   var res = window.location.search;
   console.log(res);
   //var res = JSON.parse(s);
   //document.getElementById("objekti").innerHTML = ""+res.emri+": "+res.mbiemri+" =>"+res.profili;
}



