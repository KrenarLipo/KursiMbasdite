<?php include "header.php"; ?>

<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <form action="shto.php" method="get">
                    <label for="fname">First name:</label><br>
                    <input type="text" id="fname" name="fname" required><br>
                    <label for="lname">Last name:</label><br>
                    <input type="text" id="fname" name="fname"><br>
                    <label for="myemail">Email:</label><br>
                    <input type="email" id="myemail" name="myemail" placeholder="Email" required><br>
                    <label for="selecting">Perzgjidh:</label><br>
                    <select id="selecting">
                        <option>element 1</option>
                        <option>element 2</option>
                        <option>element 3</option>
                    </select> 
                    <br> 
                    <label for="mesazhi">Mesazh:</label><br>
                    <textarea id="mesazhi" name="mesazhi"></textarea><br>
                    <label for="mycheckbox">Checkbox:</label><br>
                    <input type="checkbox" name="mycheckbox" id="mycheckbox" value="Vehicle 1"><br>
                    <label for="year">Viti:</label><br>
                    <input type="number" id="year" name="year"><br><br>
                    <input id="shfaqInfo" type="button" value="Submit">
                </form>
            </div>
            <div class="col-xs-12 col-md-4">
                <p id="resultati"></p>
            </div>
            <div class="col-xs-12 col-md-2">
                <p class="vendi_punes">Teksti <span>yne</span> fillestar</p>
                <p class="test_string">Testim Stringu</p>
                <button class="btn btn-success paraP">Para</button>
                <button class="btn btn-default pasP">Pas</button>
                <button class="btn btn-success beforeP">Before span</button>
                <button class="btn btn-default afterP">After span</button>
                <button class="btn btn-danger testString">TEST</button>
            </div>
        </div>
    </div>


<?php include "footer.php"; ?>