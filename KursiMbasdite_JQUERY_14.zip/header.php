<!DOCTYPE html>
<html>
<head>
<title>faqja jone</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="css/style2.css" type="text/css">
<link rel="stylesheet" href="css/animations.css" type="text/css">
</head>

<nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#examplemenu" aria-expanded="false">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> 
                <a class="navbar-brand" href="index.php">Logo</a>
            </div> 
            <div class="collapse navbar-collapse" id="examplemenu">
                <ul class="nav navbar-nav"> 
                    <li><a href="index.php">Home</a></li>
                    <li><a href="gallery.php">Galeria</a></li>
                    <li><a href="animations.php">Animime</a></li>
                    <li><a href="testfinders.php">Test</a></li>
                    <li><a href="aboutus.php">Rreth Nesh</a></li>
                    <li><a href="contact.php">Kontakti</a></li>
                </ul>
            </div>    
           
        </div>
    </nav>

    <div id="header"></div>